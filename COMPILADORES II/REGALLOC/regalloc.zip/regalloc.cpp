#include <bits/stdc++.h>

using namespace std;


// Constante para auxiliar na busca
constexpr int NODE_NOT_FOUND = -1;

// Estrutura que representa um nó (registrador) no grafo de interferência.
struct RegisterNode {
    int id;                             // Número do registrador (virtual ou físico)
    set<int> neighbors;                 // Conjunto de IDs dos vizinhos (interferências)
    bool is_potential_spill = false;    // Marcador para saída (apenas para a saída)

    RegisterNode(int i) : id(i) {}      // Construtor
};



// =============== Variáveis globais de auxílio =============== //

int graph_number = 0;
int initial_k = 0;                      // K original do arquivo
map<int, RegisterNode> initial_graph;   // Grafo lido (base para cada tentativa)
    
map<int, string> results_summary;       // Resultados para o resumo final

list<pair<int, bool>> simplify_stack;   // pair<node_id, is_spill>
map<int, int> allocated_colors;         // Cores finais atribuídas (registrador -> cor)
map<int, RegisterNode> current_graph;   // Grafo que está sendo simplificado



// ==================== Funções internas ==================== //

// Retorna o grau de um nó no grafo atual.
int get_degree(int node_id) {
    if (current_graph.count(node_id)) {
        return current_graph.at(node_id).neighbors.size();
    }
    return 0;
}

// Encontra o nó elegível para a fase Simplify.
int find_simplifiable_node(int current_k) {
    int best_node = NODE_NOT_FOUND;
    int min_degree = numeric_limits<int>::max();

    for (auto const& [id, node] : current_graph) {
        int deg = get_degree(id);

        // Condição principal: grau < K
        if (deg < current_k) {
            if (deg < min_degree) {
                // Desempate 1: Menor grau
                min_degree = deg;
                best_node = id;
            } else if (deg == min_degree) {
                // Desempate 2: Menor número do registrador virtual
                if (id < best_node) { best_node = id; }
            }
        }
    }
    return best_node;
}

// Encontra o nó potencial para Spill.
int find_spill_candidate() {
    int best_node = NODE_NOT_FOUND;
    int max_degree = -1;

    for (auto const& [id, node] : current_graph) {
        int deg = get_degree(id);

        if (deg > max_degree) {
            // Desempate 1: Maior grau
            max_degree = deg;
            best_node = id;
        } else if (deg == max_degree) {
            // Desempate 2: Menor número do registrador virtual
            if (id < best_node) { best_node = id; }
        }
    }
    return best_node;
}

// Remove nó do grafo, atualiza vizinhos e empilha.
void remove_node(int node_id, bool is_spill) {
    cout << "Push: " << node_id;
    if (is_spill) { cout << " *"; }
    cout << endl;

    // Coloca o node_id na pilha (simplify_stack)
    simplify_stack.push_front({node_id, is_spill});

    // Remove arestas e o nó do grafo (Build)
    if (current_graph.count(node_id)) {
        // Para cada vizinho, remove a aresta de interferência
        for (int neighbor_id : current_graph.at(node_id).neighbors) {
            if (current_graph.count(neighbor_id)) { 
                current_graph.at(neighbor_id).neighbors.erase(node_id); 
            }
        }
        current_graph.erase(node_id);
    }
}

// Fase Simplify e Potencial Spill
void simplify_and_spill(int current_k) {
    while (true) {
        // Checa se há algum nó virtual restante no grafo.
        bool has_virtual_nodes = false;
        for (auto const& pair : current_graph) {
            if (pair.first >= initial_k) {
                has_virtual_nodes = true;
                break;
            }
        }
        if (!has_virtual_nodes) break;  // Todos os virtuais foram empilhados.

        // Tenta simplificar
        int node_to_remove = find_simplifiable_node(current_k);

        if (node_to_remove != NODE_NOT_FOUND) {
            // Nó simplificável encontrado (Grau < K)
            remove_node(node_to_remove, false);
        } else {
            // Nenhum nó simplificável (Potencial Spill)
            node_to_remove = find_spill_candidate();
            if (node_to_remove != NODE_NOT_FOUND) { 
                remove_node(node_to_remove, true); 
            } else break; 
        }
    }
}

bool select_and_assign(int current_k) {
    bool spill_occurred = false;

    // Reconstruir o grafo e colorir na ordem inversa da pilha (LIFO)
    while (!simplify_stack.empty()) {
        int node_id = simplify_stack.front().first;
        simplify_stack.pop_front();

        set<int> unavailable_colors;
            
        for (int neighbor_id : initial_graph.at(node_id).neighbors) {
            if (neighbor_id < initial_k) {
                if (neighbor_id < current_k) {
                    unavailable_colors.insert(neighbor_id);
                }
            } else if (allocated_colors.count(neighbor_id)) {
                unavailable_colors.insert(allocated_colors.at(neighbor_id));
            }
        }
        
        int chosen_color = -1;
        for (int color = 0; color < current_k; ++color) {
            if (unavailable_colors.find(color) == unavailable_colors.end()) {
                chosen_color = color;
                break;
            }
        }

        cout << "Pop: " << node_id;
        if (chosen_color != -1) {
            // Atribuir cor
            allocated_colors[node_id] = chosen_color;
            cout << " -> " << chosen_color << endl;
        } else {
            // Spill
            cout << " -> NO COLOR AVAILABLE" << endl;
            spill_occurred = true;
            break; // Termina a coloração para este K
        }
    }

    return !spill_occurred;
}


// ==================== Funções externas (chamadas pela main) ==================== //

bool read_graph(istream& input) {
    string line;
    bool reading_interference = false;
        
    initial_graph.clear();
    results_summary.clear();
    graph_number = 0;
    initial_k = 0;

    while (getline(input, line)) {
        stringstream ss(line);
        string token;

        if (line.rfind("Grafo", 0) == 0) {
            ss >> token;
            ss >> graph_number;
            graph_number = abs(graph_number);
            reading_interference = false;
            continue;
        }
            
        if (graph_number == 0) continue;    // Ainda não encontrou o header

        if (line.rfind("K=", 0) == 0) {
            ss.ignore(2);
            ss >> initial_k;
            reading_interference = true;
            continue;
        }

        if (!reading_interference) continue; // Linhas entre K e a primeira interferência

        // Leitura das interferências: NNN --> V1 V2 V3...
        int node_id;
        ss >> node_id;
            
        if (ss.fail()) continue;    // Não conseguiu ler o ID (linha vazia, etc.)

        string separator;
        ss >> separator; // Tenta ler '-->' ou '->'

        if (separator == "-->" || separator == "->") {
            // Garante que o nó base existe (virtual ou físico)
            if (initial_graph.find(node_id) == initial_graph.end()) {
                initial_graph.emplace(node_id, RegisterNode(node_id));
            }
            
            int neighbor_id;
            while (ss >> neighbor_id) {
                // Adiciona interferência (node_id interfere com neighbor_id)
                initial_graph.at(node_id).neighbors.insert(neighbor_id);
                
                // Garante que o vizinho exista e adicione a interferência recíproca
                if (initial_graph.find(neighbor_id) == initial_graph.end()) {
                    initial_graph.emplace(neighbor_id, RegisterNode(neighbor_id));
                }
                initial_graph.at(neighbor_id).neighbors.insert(node_id);
            }
        }
    }   
    // Retorna true se um grafo completo (Grafo e K) foi lido no último ciclo
    return (graph_number != 0 && initial_k != 0);
}

// Orquestra o processo de alocação (K, K-1, ..., 2).
void run_allocation() {
    if (graph_number == 0 || initial_k == 0) return;

    cout << "Graph " << graph_number << " -> Physical Registers: " << initial_k << endl;
    cout << "----------------------------------------\n";
    for (int current_k = initial_k; current_k >= 2; --current_k) {            
        cout << "----------------------------------------\n";
        cout << "K = " << current_k << "\n\n";
        current_graph = initial_graph;
        simplify_stack.clear();
        allocated_colors.clear();

        simplify_and_spill(current_k);

        bool success = select_and_assign(current_k);

        if (success) {
            results_summary[current_k] = "Successful Allocation";
        } else {
            results_summary[current_k] = "SPILL";
        }
    }
}

void print_summary() {
    cout << "----------------------------------------\n";
    cout << "----------------------------------------\n";
    for (auto i = results_summary.rbegin(); i != results_summary.rend(); ++i) {
        int k_value = i->first;
        const string& result = i->second;
        if (k_value >= 10) {
            cout << "Graph " << graph_number << " -> K = " << k_value << ": " << result << endl;
        } else if (k_value == 2) {
            cout << "Graph " << graph_number << " -> K =  " << k_value << ": " << result;
        } else {
            cout << "Graph " << graph_number << " -> K =  " << k_value << ": " << result << endl;
        }
    }
}



int main() {
    // Desabilitar sincronização com stdio (melhora desempenho de I/O)
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    read_graph(cin);
    run_allocation();
    print_summary();

    return 0;
}